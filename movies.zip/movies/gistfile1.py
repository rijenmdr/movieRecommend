# -*- coding: utf-8 -*-
"""
Created on Fri May 31 18:29:29 2019

@author: Surhan
"""

from random import choice
from string import ascii_lowercase, digits
from django.contrib.auth.models import User